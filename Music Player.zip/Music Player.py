import time
import pygame
import numpy as np
import cv2
import paddlex as pdx

def  wecome():
    print('''
******************************
*                            *
*    欢迎来到python播放器      *
*                            *
******************************
    ''')

def getNum():
    print('''
******************************
*  1.播放         2.停止      *
*  3.暂停         4.继续      *
*  5.上一曲       6.下一曲     *
*  7.添加音量     8.减少音量    *
*  0.手势识别操控              *
*         t.退出             *
******************************
    ''')
    num = input("请选择要操作的项目")
    return num

def playMusic(path):
    pygame.mixer.init()
    pygame.mixer.music.load(path)
    pygame.mixer.music.play()


def pauseMusic():
    pygame.mixer.music.pause()

def unpauseMusic():
    pygame.mixer.music.unpause()

def stopMusic():
    pygame.mixer.music.stop()
1

def nextMusic(musciList,index):
    if index>=len(musciList)-1:
        print("已经是最后一曲了")
        return index
    else:
        index += 1
    playMusic(musicList[index])
    return index

def perMusic(musicList,index):
    if index <= 0:
        print("已经是第一首了")
        return index
    else:
        index -= 1
    playMusic(musicList[index])
    return index

def addVome(volume):
    print("当前音量值%f"%volume)
    if round(volume,1)>=1.0:
        print("已经是最大音量了")
    else:
        volume += 0.1
    pygame.mixer.music.set_volume(volume)
    return volume

def subVome(volume):
    if round(volume,1)<=0:
        print("已经是最小音量了")
    else:
        volume -= 0.1
    pygame.mixer.music.set_volume(volume)
    print("当前音量值%f" % volume)
    return volume

def gtcontrol():
    model = pdx.load_model("E:\code (1)\demo\inference_model")
    cap = cv2.VideoCapture(0)
    volume2=0.5
    while (True):
        ret, frame = cap.read()
        new_img = video_mirror_output(frame)
        cv2.imshow('frame', new_img)
        result = model.predict(new_img)

        keep_results = []
        areas = []
        for dt in np.array(result):
            cname, bbox, score = dt['category'], dt['bbox'], dt['score']
            if score < 0.5:
                continue
            print(cname)
            if (str(cname) == "go"):
                playMusic(musicList[index])
            if (str(cname) == "pause"):
                pauseMusic()
            if (str(cname) == "voicedown"):
                print("减少音量")
                volume2 =subVome(volume2)
            if (str(cname) == "voiceup"):
                print("添加音量")
                volume2 = addVome(volume2)

        if cv2.waitKey(1) & 0xFF == ord('q'):  # 按q键退出
            break


    cap.release()
    cv2.destroyAllWindows()


#镜像输出视频
def video_mirror_output(video):
    new_img=np.zeros_like(video)
    h,w=video.shape[0],video.shape[1]
    for row in range(h):
        for i in range(w):
            new_img[row,i] = video[row,w-i-1]
    return new_img


wecome()
musicList = []
for x in range(1,6):
    musicList.append(r"E:\CloudMusic\music"+str(x)+".mp3")
print(musicList)
index = 0
volume = 0.5
while True:
    time.sleep(1)
    num = getNum()
    if num == "1":
        print("播放")
        playMusic(musicList[index])
    elif num == "2":
        print("停止")
        stopMusic()
    elif num == "3":
        print("暂停")
        pauseMusic()
    elif num == "4":
        print("继续")
        unpauseMusic()
    elif num == "5":
        print("上一曲")
        index = perMusic(musicList,index)
    elif num == "6":
        print("下一曲")
        index = nextMusic(musicList,index)
    elif num == "7":
        print("添加音量")
        volume = addVome(volume)
    elif num == "8":
        print("减少音量")
        volume = subVome(volume)
    elif num == "0":
        print("手势操控")
        gtcontrol()

    elif num == "t":
        print("退出播放器")
        break
    else:
        print("输入选项有误请重新输入....")



import pygame
import os,time


class Music():

    def __init__(self,path,index=0,volum=0.5):
        pathList = []
        fileList = os.listdir(path)
        for filename in fileList:
            pathList.append(os.path.join(path,filename))
        self.pathList = pathList
        self.index = index
        self.volum = volum


    @staticmethod
    def wecome():
        print('''
        ******************************
        *                            *
        *    欢迎来到python播放器      *
        *                            *
        ******************************
            ''')


    def getNum(self):
        print('''
    ******************************
    *  1.播放         2.停止      *
    *  3.暂停         4.继续      *
    *  5.上一曲       6.下一曲     *
    *  7.添加音量     8.减少音量   *
    *           t.退出            *
    ******************************
        ''')
        num = input("请选择要操作的项目")
        return num

    def playmusic(self):
        pygame.mixer.init()
        pygame.mixer.music.load(self.pathList[self.index])
        pygame.mixer.music.play()


    def stopmusic(self):
        pygame.mixer.music.stop()


    def pausemusic(self):
        pygame.mixer.pause()

    def unpausemusic(self):
        pygame.mixer.unpause()

    def nextMusic(self):
        self.index += 1
        self.index %= len(self.pathList)
        self.playmusic()

    def pervMusic(self):
        if self.index>0:
            self.index -= 1
        else:
            self.index = len(self.pathList)-1
        self.playmusic()

    def addVolum(self):
        if round(self.volum,1) < 1:
            self.volum += 0.1
        else:
            print("最大音量了")
            return
        pygame.mixer.music.set_volume(self.volum)


    def subVolum(self):
        if round(self.volum,1) > 0:
            self.volum -= 0.1
        else:
            print("已经是最小音量了")
            return
        pygame.mixer.music.set_volume(self.volum)


